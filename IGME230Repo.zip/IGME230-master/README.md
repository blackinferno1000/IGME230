# IGME230
Repository for class asignments in IGME 230.
